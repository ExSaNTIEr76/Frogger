#ifndef JUEGO_H
#define JUEGO_H

#include "stdafx.h"
#include "Objeto.h"
#include "Player.h"
#include "Camioneta.h"

class Juego{
	
	int altura = 25;
	int puntos = 0;
	
	Player *p1 = new Player(50,1);
	
public:
	void borde();
	Juego(){}
	void play();
	
};

#endif

