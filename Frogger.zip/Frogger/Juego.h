#ifndef JUEGO_H
#define JUEGO_H

#include "Player.h"
#include "Camioneta.h"

class Juego{
	
	Player *p1 = new Player(50,1);
	
	Camioneta *camio1 = new Camioneta(3,5,5); 
	Camioneta *camio2 = new Camioneta(10,5,15); 	
	Camioneta *camio3 = new Camioneta(7,5,25); 
	
	
public:
	Juego(){}
	void play();
	
};

#endif

