#ifndef OBJETO_H
#define OBJETO_H

class ObjetoDibuja{
	
protected:
	int x;
	int y;
	char matriz[20][20];
	int color[20][20];
	int ancho;
	int alto;
	
	clock_t tempo;
	clock_t paso;
	int velocidad;
	
public:
	ObjetoDibuja( int v);
	void dibujar();
	void borrar();
};

#endif

