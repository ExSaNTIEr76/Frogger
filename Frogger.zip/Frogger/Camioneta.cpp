#include "stdafx.h"
#include "Objeto.h"
#include "Camioneta.h"

Camioneta::Camioneta(int x0, int y0, int vel) : ObjetoDibuja(vel){
	
	
	x = x0;
	y = y0;
	
	int colorAleatorio = (rand()%15)+1;
	
	//9x3:
	
	// 		____|~\_
	// 		[4x4_|_|-]
	// 		 (_)   (_)
	
	
	color[0][0]=colorAleatorio;  
	color[1][0]=colorAleatorio; 
	color[2][0]=colorAleatorio; 
	color[3][0]=colorAleatorio;
	color[4][0]=7;  
	color[5][0]=7; 
	color[6][0]=7; 
	color[7][0]=colorAleatorio;
	color[8][0]=0;
	
	color[0][1]=colorAleatorio;  
	color[1][1]=9; 
	color[2][1]=9; 
	color[3][1]=9;
	color[4][1]=4;  
	color[5][1]=4; 
	color[6][1]=4; 
	color[7][1]=4;
	color[8][1]=colorAleatorio;
	
	color[0][2]=0;  
	color[1][2]=0; 
	color[2][2]=1; 
	color[3][2]=16;
	color[4][2]=1;  
	color[5][2]=0; 
	color[6][2]=1; 
	color[7][2]=16;
	color[8][2]=1;
	
	
	
	matriz[0][0]='_';  
	matriz[1][0]='_'; 
	matriz[2][0]='_'; 
	matriz[3][0]='_';
	matriz[4][0]='|';  
	matriz[5][0]='~'; 
	matriz[6][0]='\\'; 
	matriz[7][0]='_';
	matriz[8][0]=' ';
	
	matriz[0][1]='[';  
	matriz[1][1]='4'; 
	matriz[2][1]='x'; 
	matriz[3][1]='4';
	matriz[4][1]='|';  
	matriz[5][1]='_'; 
	matriz[6][1]='|'; 
	matriz[8][1]=']';
	
	matriz[0][2]=' ';  
	matriz[1][2]=' '; 
	matriz[2][2]='('; 
	matriz[3][2]='_';
	matriz[4][2]=')';  
	matriz[5][2]=' '; 
	matriz[6][2]='('; 
	matriz[7][2]='_';
	matriz[8][2]=')';
	
	ancho = 9;
	alto = 3;
	x = x0;
	y = y0;
	
	
	
}


/// El metodo update lo tiene cada objeto pero es 
//// distinto en cada caso, por lo que se debe implementar 
/// en cada clase
bool Camioneta::update(){
	
	
	// mientras no llegue 70
	if (x<90){
		
		if(tempo+paso<clock()){
			
			// borro
			borrar();
			// muevo
			x++;
			// dibujo
			dibujar();
			
			tempo=clock(); // tomamos el tiempo para saber la proxima vez que movemos la pelotita
		}
		return true;
	}
	
	else{return false;};
	
}

