#include "stdafx.h"
#include "Objeto.h"

ObjetoDibuja::ObjetoDibuja(int vel){
	
	velocidad = vel;
	paso=CLOCKS_PER_SEC/velocidad;
	tempo=clock();	
}

void ObjetoDibuja::dibujar(){
	
	for (int i= 0; i<ancho; i++){
		for (int k= 0; k<alto; k++){
			textcolor(color[i][k]);	
			putchxy(x+i,y+k,matriz[i][k]); 
		}
	}
	
}

void ObjetoDibuja::borrar(){
	
	// antes de dibujar
	for (int i= 0; i<ancho; i++){
		for (int k= 0; k<alto; k++){
			textcolor(color[i][k]);	
			putchxy(x+i,y+k,' '); 
		}
	}
	
}

