#include "stdafx.h"
#include "Game.h"
#include "Player.h"
#include "Camioneta.h"

int main() {
	
	void Empezar();
	
	return 0;
}
