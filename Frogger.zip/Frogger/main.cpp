#include "stdafx.h"
#include "Juego.h"
#include "Player.h"
#include "Camioneta.h"

int main(int argc, char *argv[]) {
	
	srand(time(NULL));
	Juego J;
	J.borde();
	J.play();
	
	return 0;
}
