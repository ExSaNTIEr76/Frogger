#include "stdafx.h"
#include "Juego.h"

void Juego::borde() {
	
	std::cout << "+-------------------------------------------------------------------+" << std::endl;
	
	for (int i = 0; i < altura; ++i) {
		std::cout << "|                                                                   |" << std::endl;
	}
	
	std::cout << "+-------------------------------------------------------------------+" << std::endl;
	
	std::cout << "Puntaje: " <<puntos << std::endl;
}

void Juego::play(){
	
	Camioneta camioneta1(0, 5, 2);  // Aparecer� en la fila 5
	Camioneta camioneta2(0, 10, 3); // Aparecer� en la fila 10
	Camioneta camioneta3(0, 15, 7); // Aparecer� en la fila 10
	
	while (true) {
		
		p1->start();
		
		// Actualizaci�n de las camionetas
		if (!camioneta1.update()) {
			// Camioneta alcanz� su l�mite, puedes reiniciarla o hacer lo que sea necesario
			camioneta1 = Camioneta(0, 5, 2);
		}
		
		if (!camioneta2.update()) {
			// Camioneta alcanz� su l�mite, puedes reiniciarla o hacer lo que sea necesario
			camioneta2 = Camioneta(0, 10, 3);
		}
		
		if (!camioneta3.update()) {
			// Camioneta alcanz� su l�mite, puedes reiniciarla o hacer lo que sea necesario
			camioneta2 = Camioneta(0, 15, 7);
		}
	}
}

