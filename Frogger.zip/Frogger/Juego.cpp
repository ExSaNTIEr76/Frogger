#include "stdafx.h"
#include "Juego.h"

void Juego::play(){
	
	/**
	aca de debe ir una condicion de corte que finalice el juego
	en un juego con interacciones se suele hacer un while true y corta
	alguna accion en el juego: vida = 0; algujna tecla, etc.
	En este ejemplo el metodo update dira cuando cortar cuando
	el contador llegue a 0 lanzara un false
	**/
	
	bool flag = true;
	while(flag) {
		flag = camio1->update();
		// el objeto 1 es el ultimo en terminar
		camio2->update();
		camio3->update();
		p1->start();
		
	}
	
}

