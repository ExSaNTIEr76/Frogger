#include "Tiempo.h"

Tiempo::Tiempo() {
	
}

