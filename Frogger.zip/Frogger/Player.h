#ifndef PLAYER_H
#define PLAYER_H

class Player{
	
	const int bordeSup = 1;
	const int bordeIzq = 1;
	const int bordeDer = 80;
	const int bordeInf = 20;
	
	clock_t tempo;
	clock_t paso;
	int direccionX;
	int direccionY;
	int col;
	int x,y;
	
public:
	
	void borrar();
	void dibujar();
	void mover();
	Player(int velocidad,int color);
	void start();
	
	
};

#endif

