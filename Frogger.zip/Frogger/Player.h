#ifndef PLAYER_H
#define PLAYER_H

class Player {
public:
	Player();
private:
	void Mover();
};

#endif

