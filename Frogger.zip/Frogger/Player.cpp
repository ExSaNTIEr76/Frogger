#include "stdafx.h"
#include "Objeto.h"
#include "Player.h"

Player::Player(int velocidad, int color=LIGHTGREEN){
	
	paso=CLOCKS_PER_SEC/velocidad;
	tempo=clock();
	col=color;
	direccionX = 1;
	direccionY = 1;
	x=rand()%20+1;
	y=rand()%20+1;
}

void Player::start(){
	textcolor(col);
	
	if(tempo+paso<clock()){
		borrar();
		mover();
		dibujar();
		tempo=clock();
	}
}

void Player::borrar(){
	gotoxy(x,y);
	textcolor(7);
	textcolor(col);
}

void Player::dibujar(){
	std::cout << "@";
}

void Player::mover() {
	if (_kbhit()) {
		char tecla = _getch();
		
		switch (tecla) {
		case 'w':
			y--;
			break;
		case 's':
			y++;
			break;
		case 'a':
			x--;
			break;
		case 'd':
			x++;
			break;
		}
	}
}	

