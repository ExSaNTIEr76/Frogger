#include "stdafx.h"
#include "Player.h"

Player::Player() {
	
}

