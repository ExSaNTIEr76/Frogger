#ifndef STDAFX_H
#define STDAFX_H

#include <iostream>
#include <conio2.h>
#include <ctime>
#include <windows.h>

#endif
