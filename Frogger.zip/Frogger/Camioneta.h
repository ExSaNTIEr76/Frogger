#ifndef CAMIONETA_H
#define CAMIONETA_H

class Camioneta : public ObjetoDibuja {
	
public:
	Camioneta(int x0, int y0, int vel);

	bool update();
};

#endif

