#ifndef CAMIONETA_H
#define CAMIONETA_H

class Camioneta{
	
	int x;
	int y;
	char Matriz[9][3];
	char color[9][3]; // matriz de colores
	int ancho;
	int alto;
	int colorAleatorio;
	
	clock_t tempo;
	clock_t paso;
	int velocidad;
	
public:
	Camioneta(int,int,int);
	void dibujar();
	bool update();
	void borrar();
};

#endif

